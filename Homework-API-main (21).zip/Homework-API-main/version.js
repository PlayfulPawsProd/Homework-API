// version.js - Holds the current app version and update notes! Nyaa~!

const APP_VERSION = "1.6.1"; // Change this when you update!
const APP_UPDATE_NOTE = "Added Mika-Gotchi Poo Incident & About Popup! 💩✨ Added chat to Gotchi page! Notifications!"; // Describe the latest cool thing!